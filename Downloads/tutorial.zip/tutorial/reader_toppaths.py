import matplotlib.pyplot as plt

files = ["/Users/robertnims/Downloads/tutorial/6percent-ctrl-"]
ending="/TEMPLATE_opt.log"

samples_pergroup = 4

for k in files:
    for i in range(0, samples_pergroup):
        file_k = k+str(i+1)+ending
        print file_k
        f = open(file_k)
        j = 0
        vecfit = []
        vecdata = []
        for line in reversed(f.readlines()):
            j+=1
            if j>14:
                a = line.find('-',2)
                b = line.find(' ',a+2)
                c = line.find('-',b+2)
                cprime = line.find('e',b+2)
                if c == cprime+1:
                    break
                d = line.find(' ',c+2)
                if c == -1:
                    break
                else:
                    vecfit.insert(0,float(line[a:b]))
                    vecdata.insert(0,float(line[c:d]))
    #print vecfit
    #print vecdata
        plt.plot(vecfit,color='r')
        plt.plot(vecdata,color='b')
        plt.show()
