import subprocess as sb 
frun = open('filesrun.dat','w')
filenum = 0

path_to_FEBio = "/Users/robertnims/Downloads/tutorial/FEBio-1/febio.osx"

filepath = ["/Users/robertnims/Downloads/tutorial/6percent-ctrl-"]

samples_pergroup = 4

ending1 = "/TEMPLATE_opt.feb"
ending2 = "/TEMPLATE_opt.log"

for j in filepath:
    for k in range(0, samples_pergroup):
        file_i = j+str(k+1)+ending1
        print file_i
        sb.call([path_to_FEBio,"-s",file_i])
        filenum+=1
        frun.write(str(filenum)+' ')
        i = 0
        for line in reversed(open(j+str(k+1)+ending2).readlines()):
            i+=1
            if i == 2:
                if line.replace(' N O R M A L   T E R M I N A T I O N\n','xx') == 'xx':
                    frun.write('normal\n')
                else:
                    frun.write('fail\n')

fsave=open('file.dat','a')
savenum = 0

for i in filepath:
    for k in range(0, samples_pergroup):
        file_i = i+str(k+1)+ending2
        f = open(file_i)
        savenum+=1
        fsave.write(str(savenum)+'\n')
        j = 0
        for line in reversed(f.readlines()):
            j+=1
            if j>5:
                break
            else:
                if j>2:
                    fsave.write(line)
